"""Bind unmodified Mstar reflection/patching code to the review host and API.

Source modules are loaded without their optional provider/tracing imports. The
original Reflector owns patch extraction, application, full-code fallback and
compile-fix iteration. Only model transport, prompts and validation are bound
to AgentReview; generated code executes only in the existing sandbox.
"""
from __future__ import annotations

import ast
from pathlib import Path
import sys
from types import ModuleType, SimpleNamespace
from uuid import uuid4

from .io import atomic_write_json, file_sha256, read_json, value_sha256
from .program_checks import DEFAULT_IMPORT_WHITELIST, ALLOWED_FIELD_TYPES, FORBIDDEN_CALLS
from .program_validation import validate_program

UPSTREAM = Path(__file__).parent / "vendor/mstar"


class ReflectionFailure(ValueError):
    failure_category = "candidate"
    repair_exhausted = True


def source_identity():
    manifest = read_json(UPSTREAM / "manifest.json")
    files = [(UPSTREAM / name, sha) for name, sha in manifest["files"].items()]
    dependency = manifest["patch_dependency"]
    files += [(Path(dependency["root"]) / name, sha) for name, sha in dependency["files"].items()]
    for path, sha in files:
        if file_sha256(path) != sha:
            raise ValueError(f"Frozen Mstar source/dependency changed: {path}")
    return [{"path": str(path.resolve()), "sha256": sha} for path, sha in files]


def _load(name, bindings):
    path = UPSTREAM / f"{name}.py"
    tree = ast.parse(path.read_text(), filename=str(path))
    # Leave upstream function/class bodies intact. Replace only unavailable
    # package/provider imports with the explicit host bindings below.
    tree.body = [n for n in tree.body if not (
        isinstance(n, ast.ImportFrom) and (n.module or "").startswith("mstar")
        or isinstance(n, ast.Import) and any(a.name == "weave" for a in n.names))]
    module = ModuleType(f"_agentreview_mstar_{name}_{uuid4().hex}")
    module.__dict__.update(bindings, __file__=str(path))
    sys.modules[module.__name__] = module
    exec(compile(tree, str(path), "exec"), module.__dict__)
    return module


def interface_spec(runtime):
    write_calls = max(0, runtime["build_llm_calls"] - 1)
    return f"""AgentReview task interface (authoritative for this host):
- Define KnowledgeItem and Query dataclasses, KnowledgeBase, and the four existing
  memory instruction strings. JSON-compatible field types: {sorted(ALLOWED_FIELD_TYPES)}.
- Keep Query.query_text and Query.reviewer_dimension. Preserve the exact
  plan_review function and the imports it uses: only the memory strategy evolves.
- KnowledgeBase.__init__(self, toolkit), write(self, item, raw_text), read(self, query).
  Put memory helper methods inside KnowledgeBase. No additional top-level helpers.
- Candidate-visible toolkit methods: llm_completion(messages, **kwargs) -> str;
  embed(list_of_texts); create_vector_collection(name); log(event, payload);
  count_tokens(text); memory_token_limit(purpose='context');
  select_memory_entries(list_of_complete_text_entries, purpose='context').
  For summary input use purpose='summary_input'. toolkit.db is in-memory SQLite,
  toolkit.chroma is the existing collection facade; toolkit.logger.debug is available.
- These are the complete public capabilities; toolkit.memory_runtime and
  toolkit.max_llm_calls_per_operation DO NOT exist in the candidate sandbox.
  The following call allowances are host configuration, not accessible attributes:
  write may use {write_calls} LLM calls, read may use {runtime['read_llm_calls']}.
  The host already reserves one build call for KnowledgeItem induction.
- Allowed imports: {', '.join(sorted(DEFAULT_IMPORT_WHITELIST))}.
  Unsupported builtins: {', '.join(sorted(FORBIDDEN_CALLS))}.
- read returns a complete string within the model context.
  Preserve complete selected entries and complete model responses; no character
  truncation or hardcoded short output budgets. Omit max_tokens to use model capacity.
  Normal list operations and removal of JSON/Markdown syntax delimiters are allowed.
- Each role has independent memory. Never write rotating/test feedback into build
  memory. Do not catch and hide model, embedding, capability or budget failures.
- A patch must contain one `*** Update File: program.py` section with all hunks
  in source order. Repeated sections overwrite each other in the native patch
  dependency; they are rejected so the original format-repair loop can fix them.
"""


def _adapt_prompt(text):
    # Capacity/interface substitutions only; original patch grammar stays intact.
    text = text.replace('4. `read()` must return at most 3000 characters — do not return all stored text.',
                        '4. `read()` returns complete selected memory within the model context.')
    text = text.replace('3. Only use allowed imports: json, re, math, hashlib, collections, dataclasses, typing, datetime, textwrap, sqlite3, chromadb.',
                        '3. Use only the allowed imports in the task interface above.')
    return text


class MstarReflection:
    def __init__(self, *, client, model, runtime, directory, validator=None, max_fix_attempts=3):
        self.client, self.model, self.runtime = client, model, runtime
        self.directory = Path(directory)
        self.directory.mkdir(parents=True, exist_ok=True)
        self.events, self.calls, self.modules = [], [], []
        self.source = source_identity()
        manifest = read_json(UPSTREAM / "manifest.json")
        dependency = str(Path(manifest["patch_dependency"]["root"]).parent)
        if dependency not in sys.path:
            sys.path.insert(0, dependency)
        types = self._module("types", {})
        self.prompts = self._module("prompts", vars(types))
        spec = interface_spec(runtime)
        self.prompts.KB_INTERFACE_SPEC = spec
        # Replace the upstream example advocating a 3000-char cap with a
        # semantics-preserving example. Keep the actual V4A specification.
        self.prompts.PATCH_FORMAT_SPEC = self.prompts.PATCH_FORMAT_SPEC.split("Example — replacing a return value:")[0]
        patcher = self._module("patcher", {})
        def apply_patch(code, body):
            if sum(line.strip() == "*** Update File: program.py" for line in body.splitlines()) > 1:
                raise ValueError("Repeated program.py update sections would lose changes; use one section with multiple hunks")
            return patcher.apply_patch(code, body)
        logger = SimpleNamespace(log=lambda message, header=None: self.events.append({"header": header, "message": message}))
        bindings = {**vars(types), **vars(self.prompts), "apply_patch": apply_patch,
                    "weave": SimpleNamespace(op=lambda: lambda fn: fn),
                    "get_logger": lambda: logger, "completion_with_retry": self._complete,
                    "build_compile_fix_prompt": lambda **kw: _adapt_prompt(self.prompts.build_compile_fix_prompt(**kw)),
                    "build_patch_format_fix_prompt": lambda **kw: _adapt_prompt(self.prompts.build_patch_format_fix_prompt(**kw)),
                    "build_reflection_user_prompt": lambda **kw: self.initial_prompt}
        module = self._module("reflector", bindings)
        self.types = types
        host_validate = validator or self._validate
        adapter = self
        class ReviewReflector(module.Reflector):
            def _validate_code(self, code):
                number = len(adapter.events)
                path = adapter.directory / "validation" / f"{number:03d}.py"
                adapter._write(path, code)
                error = host_validate(path)
                adapter.events.append({"validation_source": str(path), "error": error})
                adapter._save()
                return ("AgentReview compile/smoke error", error) if error else None
        self.reflector = ReviewReflector(model=model.model, max_fix_attempts=max_fix_attempts)

    def _module(self, name, bindings):
        # Never copy another module's identity into the new namespace.
        module = _load(name, {k: v for k, v in bindings.items() if not k.startswith('__')})
        self.modules.append(module)
        return module

    @staticmethod
    def _write(path, text):
        path.parent.mkdir(parents=True, exist_ok=True)
        if path.exists():
            if path.read_text() != text:
                raise ValueError(f"Recorded Mstar text changed: {path}")
        else:
            path.write_text(text)

    def _validate(self, path):
        errors = validate_program(path, require_bubblewrap=True, memory_runtime=self.runtime, seed_kind="evolved")
        return "\n".join(errors) if errors else None

    def _save(self):
        atomic_write_json(self.directory / "mstar-trace.json", {
            "protocol": "mstar-upstream-patch-v1", "source": self.source,
            "max_fix_attempts": self.reflector.max_fix_attempts,
            "calls": self.calls, "events": self.events}, immutable=False)

    def _complete(self, *, messages, **kwargs):
        index = len(self.calls)
        raw = self.client.complete(messages, max_tokens=self.model.max_output_tokens,
                                   component="shared_mstar_reflection")
        path = self.directory / "responses" / f"{index:03d}.txt"
        self._write(path, raw)
        self.calls.append({"index": index, "messages_sha256": value_sha256(messages),
                           "path": str(path), "sha256": file_sha256(path)})
        self._save()
        return SimpleNamespace(choices=[SimpleNamespace(message=SimpleNamespace(content=raw))])

    def prompt(self, code, score, iteration):
        text = self.prompts.build_reflection_user_prompt(code=code, score=score, failed_cases=[], iteration=iteration)
        return _adapt_prompt(text) + "\n\nComplete AgentReview rotating feedback and lineage:\n"

    def run(self, *, code, prompt, iteration, score, violation=None):
        self.initial_prompt = prompt
        try:
            if violation is not None:
                result = self.reflector.fix_runtime_violation(code, violation)
                change = "Mstar runtime repair: " + violation
            else:
                reflected = self.reflector.reflect_and_mutate(
                    self.types.KBProgram(source_code=code), self.types.EvalResult(score=score), iteration)
                result = reflected.program.source_code if reflected is not None else None
                change = reflected.commit_message if reflected is not None else None
            if result is None:
                raise ReflectionFailure("Mstar exhausted its patch/compile/smoke repair loop; see mstar-trace.json")
            return result, change or "Mstar memory program update"
        finally:
            self._save()
            for module in self.modules:
                sys.modules.pop(module.__name__, None)
