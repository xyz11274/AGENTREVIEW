import ast
from agentreview.research_v2.program_checks import _text_slice_errors


def test_markdown_fence_parsing_is_a_list_operation():
    tree = ast.parse('''def parse(text):
    lines = text.splitlines()
    if lines and lines[0].startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].startswith("```"):
        lines = lines[:-1]
    return "\\n".join(lines)
''')
    assert _text_slice_errors(tree) == []


def test_reassignment_to_text_is_not_a_proven_list():
    tree = ast.parse('''def parse(text):
    lines = text.splitlines()
    lines = text
    return lines[:100]
''')
    assert _text_slice_errors(tree)
