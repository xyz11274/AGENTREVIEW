"""Three independent MSTAR searches, then all three frozen paired evaluations."""
from pathlib import Path
import argparse
import fcntl
import json
import os
import sys
import time

REPO = Path(__file__).resolve().parents[1]
ROOT = REPO / "artifacts/study-0930-api"
SEEDS = (0, 1000, 2000)
sys.path.insert(0, str(REPO / "AgentReview"))
from agentreview.research_v2.io import atomic_write_json, read_json, value_sha256
from agentreview.research_v2.shared_experiment import APISharedBackend, binding, bound, runtime_identity, generation_identity, run_shared_final_test
from agentreview.research_v2.shared_evolution import SharedEvolution
from agentreview.research_v2.experiment_protocol import load_experiment_protocol
from agentreview.research_v2.development_coco import validate_assessment_receipt


def run():
    study = read_json(ROOT / "study.frozen.json")
    if study["implementation"]["runtime"] != runtime_identity() or study["implementation"]["launcher"] != binding(__file__):
        raise ValueError("Running study requires its exact frozen implementation")
    bound(study["implementation"]["reporter"])
    state_path = ROOT / "study-state.json"
    state = read_json(state_path) if state_path.exists() else {"study_id":study["study_id"],"status":"running","phase":"searches","searches":{},"final":{}}
    if state["study_id"] != study["study_id"]:
        raise ValueError("Study resume requires identical frozen configuration")
    def save():
        state["updated_at"] = time.time()
        atomic_write_json(state_path, state, immutable=False)
    def environment(protocol, run_root):
        os.environ["AGENTREVIEW_TELEMETRY_ROOT"] = str(run_root / "telemetry")
    try:
        with (ROOT / "study.lock").open("a+b") as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            state.update(status="running", pid=os.getpid())
            save()
            for spec in study["searches"]:
                seed, run_root = spec["seed"], Path(spec["run_root"])
                protocol = load_experiment_protocol(bound(spec["protocol"]))
                environment(protocol, run_root)
                launch = run_root / "launched.json"
                if not launch.exists():
                    atomic_write_json(launch, {"started":time.time(),"protocol":spec["protocol"],"independent_search_seed":seed})
                state.update(phase="searches", active_search_seed=seed)
                save()
                host = APISharedBackend(protocol=protocol, output_root=run_root / "search")
                engine = SharedEvolution(protocol=protocol, output_root=run_root / "search", backend=host)
                evidence = run_root / "repair-evidence.json"
                started = time.monotonic()
                result = engine.run(repair_evidence=evidence if evidence.exists() else None)
                timing = run_root / "phase-timings.json"
                times = read_json(timing) if timing.exists() else {}
                times["search_seconds"] = times.get("search_seconds", 0) + time.monotonic() - started
                atomic_write_json(timing, times, immutable=False)
                state["searches"][str(seed)] = {"status":result["status"], "attempts_recorded":len(result["attempts"]),
                    "checkpoint":str(engine.state_path)}
                save()
                if result["status"] not in {"complete","ended"} or result.get("winner") is None:
                    state.update(status="paused", reason=f"Search {seed} requires diagnosis; no final evaluation opened")
                    save()
                    return
                frozen = result["winner"]
                for key, assessment in frozen["assessments"].items():
                    host.validate(assessment, recipe=frozen["recipes"][key], epoch=assessment["evaluation_epoch"])
                dev = run_root / "development-final.json"
                if not dev.exists():
                    started = time.monotonic()
                    winner = frozen["winner"]
                    host.frozen_snapshots[winner["candidate_id"]] = winner["identity"]["snapshots"]
                    recipe = {**result["recipes"][winner["key"]], "key":"champion-development-final"}
                    assessment = host.assess(recipe, epoch=engine.epoch)
                    host.validate(assessment, recipe=recipe, epoch=engine.epoch)
                    atomic_write_json(dev, {"recipe":recipe,"result":assessment,"selection_changed":False})
                    times["development_final_seconds"] = time.monotonic() - started
                atomic_write_json(timing, times, immutable=False)
                dev_record = read_json(dev)
                host.validate(dev_record["result"], recipe=dev_record["recipe"], epoch=engine.epoch)
                state["searches"][str(seed)]["frozen_system"] = binding(run_root / "search/winner.json")
                save()
            freeze_all = {"protocol":"three-search-freeze-v1","status":"all_frozen", "random_seeds":list(SEEDS),
                "generation_identity":generation_identity(), "systems":[{"seed":spec["seed"], "protocol":spec["protocol"],
                    "frozen_system":state["searches"][str(spec["seed"])]["frozen_system"]} for spec in study["searches"]]}
            atomic_write_json(ROOT / "all-systems-frozen.json", freeze_all)
            for spec in study["searches"]:
                seed, run_root = spec["seed"], Path(spec["run_root"])
                protocol = load_experiment_protocol(bound(spec["protocol"]))
                environment(protocol, run_root)
                state.update(phase="final_evaluation", active_search_seed=seed)
                save()
                started = time.monotonic()
                final = run_shared_final_test(protocol_path=bound(spec["protocol"]), output_root=run_root / "final",
                    frozen_system_path=run_root / "search/winner.json")
                timing = run_root / "phase-timings.json"
                times = read_json(timing)
                times["final_seconds"] = times.get("final_seconds", 0) + time.monotonic() - started
                atomic_write_json(timing, times, immutable=False)
                state["final"][str(seed)] = {"status":final["status"], "checkpoint":str(run_root / "final/final-test.json")}
                save()
                if final["status"] != "complete":
                    state.update(status="paused", reason="Final evaluation failed; no score imputation or evolutionary feedback")
                    save()
                    return
                from paired_benchmark_report import report
                report(run_root)
            aggregate_report(study)
            state.update(status="complete", phase="reported_all_three")
            save()
    except Exception as exc:
        state.update(status="paused", error={"type":type(exc).__name__,"message":str(exc)})
        save()
        raise


def aggregate_report(study):
    import csv
    from paired_benchmark_report import paired_summary
    rows, champions = [], {}
    for spec in study["searches"]:
        root = Path(spec["run_root"])
        summary = read_json(root / "report/paired-summary.json")
        data = list(csv.DictReader((root / "report/paired-paper-deltas.csv").open()))
        champions[spec["seed"]] = {row["paper_id"]:float(row["champion"]) for row in data}
        families = {row["paper_id"]:row["work_family"] for row in data}
        rows.append({"search_seed":spec["seed"],"summary":binding(root / "report/paired-summary.json"),
            "primary_results":{key:summary["comparisons"][key] for key in summary["primary_control_keys"]},
            "throughput":summary["throughput"]})
    differences = {}
    for index, seed in enumerate(SEEDS):
        for other in SEEDS[index+1:]:
            differences[f"{seed}_minus_{other}"] = paired_summary(champions[seed], champions[other], families, seed=20260917, resamples=10000)
    atomic_write_json(ROOT / "three-search-results.json", {"status":"complete","paper_count":1300,
        "prespecified_search_seeds":list(SEEDS),"runs":rows,"between_champion_differences":differences,
        "test_based_run_selection":False,"all_results_reported":True})


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("action", choices=("run",))
    args = parser.parse_args()
    run()
