"""Prepare and run only the independent 15-paper, five-round API pilot."""
from __future__ import annotations

import argparse
import copy
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import threading
import time

REPO = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO / "AgentReview"))
from agentreview.research_v2.io import atomic_write_json, read_json
from agentreview.research_v2.experiment_protocol import load_experiment_protocol, _identity_keys
from agentreview.research_v2.shared_experiment import (
    APISharedBackend, binding, bound, runtime_identity, run_shared_experiment, run_shared_final_test,
)

CONFIG = REPO / "config/0930-pilot"
DATA = REPO / "data/pilot-0930"
ROOT = REPO / "artifacts/pilot-0930"
PROTOCOL = CONFIG / "protocol.frozen.json"
SPLIT_SEED = 20260929
COUNTS = {"build": 4, "static": 3, "rotating": 5, "sealed_test": 3}


def stratified(rows, count, label):
    """Reproducible venue/year-balanced ordering, independent of any scores."""
    def rank(value):
        return hashlib.sha256(f"{SPLIT_SEED}:{label}:{value}".encode()).hexdigest()
    groups = {}
    for row in rows:
        groups.setdefault(row["venue_year"], []).append(row)
    groups = {key: sorted(group, key=lambda row: rank(row["paper_id"]))
              for key, group in groups.items()}
    ordered = []
    while len(ordered) < count:
        for key in sorted(groups, key=rank):
            if groups[key]:
                ordered.append(groups[key].pop(0))
                if len(ordered) == count:
                    return ordered
        if not any(groups.values()):
            raise ValueError("Insufficient unique papers for the pilot")


def subset_jsonl(source, target, ids):
    rows = {str(row["id"]): row for row in map(json.loads, source.read_text().splitlines())}
    text = "".join(json.dumps(rows[pid], ensure_ascii=False) + "\n" for pid in ids)
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and target.read_text() != text:
        raise ValueError(f"Existing pilot input changed: {target}")
    target.write_text(text, encoding="utf-8")
    return binding(target)


def prepare():
    original = REPO / "data/paired"
    sources = {split: read_json(original / split / "manifest.json")["records"]
               for split in COUNTS}
    rotating_and_test = stratified(sources["rotating"], 8, "rotating_and_test")
    chosen = {"build": stratified(sources["build"], 4, "build"),
              "static": stratified(sources["static"], 3, "static"),
              "rotating": rotating_and_test[:5], "sealed_test": rotating_and_test[5:]}
    original_test_keys = {key for row in sources["sealed_test"] for key in _identity_keys(row)}
    pilot_keys = {key for rows in chosen.values() for row in rows for key in _identity_keys(row)}
    if pilot_keys & original_test_keys:
        raise ValueError("Pilot must not use any original sealed-test identity or family")
    split_bindings = {}
    for split, rows in chosen.items():
        origin = "rotating" if split == "sealed_test" else split
        directory = DATA / split
        ids = [row["paper_id"] for row in rows]
        reference = None
        if split != "build":
            reference = copy.deepcopy(read_json(original / origin / "scoring-only/references.json"))
            assets = directory / "scoring-only"
            reference.update(partition=split, paper_ids=ids)
            reference["benchmark_files"] = [subset_jsonl(
                bound(reference["benchmark_files"][0]), assets / "benchmark.jsonl", ids)]
            reference["complete_human_classify_file"] = subset_jsonl(
                bound(reference["complete_human_classify_file"]), assets / "human.jsonl", ids)
            selected = read_json(bound(reference["reviewer_selection_file"]))
            atomic_write_json(assets / "selection.json", {pid: selected[pid] for pid in ids})
            reference["reviewer_selection_file"] = binding(assets / "selection.json")
            atomic_write_json(assets / "references.json", reference)
            reference = binding(assets / "references.json")
        records = []
        for original_row in rows:
            row = copy.deepcopy(original_row)
            paper = read_json(bound(row["assets"]["paper"]))
            paper["source"].update(source_partition=split, pilot_origin_partition=origin)
            path = directory / "papers" / f"{row['paper_id']}.json"
            atomic_write_json(path, paper)
            row.update(source_partition=split, pilot_origin_partition=origin)
            row["assets"] = {"paper": binding(path)}
            if reference:
                row["assets"]["coco_reference"] = reference
            records.append(row)
        atomic_write_json(directory / "manifest.json", {
            "protocol": "shared-memory-split-v1", "split": split, "records": records})
        split_bindings[split] = binding(directory / "manifest.json")
    atomic_write_json(DATA / "family-audit.json", {
        "status": "complete", "method": "Seeded venue/year-balanced selection; full identity/family/content disjointness verified by protocol loader",
        "split_manifest_sha256": {key: value["sha256"] for key, value in split_bindings.items()},
        "original_sealed_test_identity_overlap": 0})
    atomic_write_json(DATA / "cohort.json", {"paper_ids": [r["paper_id"] for r in chosen["sealed_test"]],
        "purpose": "Pilot held-out cohort drawn from original rotating development, never the 1300-paper test",
        "strictly_unseen_claim": False})
    atomic_write_json(DATA / "allocation.json", {
        "split_seed": SPLIT_SEED, "counts": COUNTS,
        "selection": "Venue/year-balanced, SHA256 order; no score or text-length filtering",
        "sources": {split: binding(original / split / "manifest.json") for split in COUNTS},
        "paper_ids": {split: [row["paper_id"] for row in rows] for split, rows in chosen.items()},
        "original_sealed_test_identity_overlap": 0,
        "history": "Development assignment in earlier versions is retained in the historical inventory; pilot is not a historically unseen test"})
    services = read_json(REPO / "config/0930/services.json")
    services["state_root"] = str(ROOT / "services")
    # GPU allocation is an operational prerequisite; no other user's processes are stopped.
    for service in services["services"].values():
        service["gpus"] = []
    service_path = CONFIG / "services.json"
    if not service_path.exists():
        atomic_write_json(service_path, services)
    config = read_json(REPO / "config/0930/protocol.seed-0.frozen.json")
    config.pop("study")
    config.update(experiment_id="0930-pilot-deepseek-five-rounds-seed-0", splits=split_bindings,
        claim_scope="Exploratory single-search pilot; independently partitioned development data; no full-scale experiment")
    config["embedding"]["cache_path"] = str(ROOT / "embedding.sqlite3")
    config["evolution"].update(attempts=5, rotating_sample_size=3, detailed_reflection_cases=2,
        detailed_case_rule="Two lowest scores from three sampled rotating papers; overview of all three")
    config["deduplication"]["family_audit"] = binding(DATA / "family-audit.json")
    config["evaluation_design"].update(expected_counts=COUNTS,
        protocol="paired-existing-benchmark-pilot-v1",
        comparison_units="One search with three seed memory strategies and eight final arms; all five attempts reported",
        original_evaluation_basis=binding(DATA / "cohort.json"),
        original_split_bindings={"pilot_source": binding(original / "rotating/manifest.json")},
        development_split_bindings={key: split_bindings[key] for key in ("build", "static", "rotating")},
        cohort_selection=binding(DATA / "cohort.json"))
    config["implementation"] = {"runtime": runtime_identity(), "launcher": binding(__file__),
        "reporter": binding(REPO / "deployment/evolution_round_report.py"),
        "paired_reporter": binding(REPO / "deployment/paired_benchmark_report.py")}
    config["services_config"] = config["service_configuration"] = binding(service_path)
    config["launch_policy"] = {"reason": "Only this 15-paper pilot is authorized; no automatic full-study launch"}
    atomic_write_json(PROTOCOL, config)
    protocol = load_experiment_protocol(PROTOCOL)
    ROOT.mkdir(parents=True, exist_ok=True)
    atomic_write_json(ROOT / "protocol.frozen.json", read_json(PROTOCOL))
    from evolution_round_report import report
    report(ROOT)
    return {"status": "prepared", "counts": COUNTS, "rounds": 5, "independent_searches": 1,
            "initial_memory_strategies": 3, "final_arms": 8, "protocol_sha256": protocol.protocol_sha256,
            "run_root": str(ROOT), "full_experiment_authorized": False}


def check():
    protocol = load_experiment_protocol(PROTOCOL)
    implementation = protocol.document["implementation"]
    if implementation["runtime"] != runtime_identity():
        raise ValueError("Pilot runtime differs from the frozen implementation")
    for key in ("launcher", "reporter", "paired_reporter"):
        bound(implementation[key])
    backend = APISharedBackend(protocol=protocol, output_root=ROOT / "preflight" / protocol.protocol_sha256)
    backend.preflight()
    from agentreview.research_v2.llm import require_api_key
    from agentreview.research_v2.development_coco_worker import _runtime
    from agentreview.research_v2.config import ModelConfig
    require_api_key(backend.model)
    require_api_key(ModelConfig(**backend.scoring["services"]["judge"]))
    subprocess.run(["bwrap", "--unshare-all", "--ro-bind", "/", "/", "--proc", "/proc",
                    "--dev", "/dev", "--", "/bin/true"], check=True, capture_output=True)
    services, blockers = {}, []
    for stage in ("split", "classify"):
        try:
            services[stage] = _runtime(backend.scoring, stage)
        except (OSError, ValueError) as exc:
            blockers.append({"stage": stage, "error": str(exc)})
    value = {"status": "ready" if not blockers else "blocked", "counts": COUNTS,
             "offline_protocol_and_scoring_validation": "passed", "sandbox": "passed",
             "credential_configured": True, "services": services, "blockers": blockers,
             "model_calls": 0, "checked_at": time.time()}
    atomic_write_json(ROOT / "readiness.json", value, immutable=False)
    return value


def allocate(gpus):
    if len(gpus) != 4 or len(set(gpus)) != 4 or min(gpus) < 0:
        raise ValueError("The retained TP2 Split and TP2 Classify deployment needs four distinct GPU IDs")
    if (ROOT / "launched.json").exists() or (ROOT / "search/search.json").exists():
        raise ValueError("Allocate GPUs before starting the frozen pilot")
    services_path = CONFIG / "services.json"
    services = read_json(services_path)
    services["services"]["split"]["gpus"] = gpus[:2]
    services["services"]["classify"]["gpus"] = gpus[2:]
    atomic_write_json(services_path, services, immutable=False)
    protocol = read_json(PROTOCOL)
    protocol["services_config"] = protocol["service_configuration"] = binding(services_path)
    atomic_write_json(PROTOCOL, protocol, immutable=False)
    atomic_write_json(ROOT / "protocol.frozen.json", protocol, immutable=False)
    return {"split_gpus": gpus[:2], "classify_gpus": gpus[2:], "services_started": False}


def evaluate_rounds(protocol, search, final):
    """Held-out trajectory, evaluated only after search and Champion freeze."""
    frozen_path = ROOT / "search/winner.json"
    frozen = read_json(frozen_path)
    path = ROOT / "round-test/final-rounds.json"
    state = read_json(path) if path.exists() else {
        "status": "running", "freeze_id": frozen["freeze_id"], "recipes": {}, "results": {}}
    if state["freeze_id"] != frozen["freeze_id"] or final["freeze_id"] != frozen["freeze_id"]:
        raise ValueError("Round trajectory requires the same verified final freeze")
    host = APISharedBackend(protocol=protocol, output_root=ROOT / "round-test")
    host.frozen_system = binding(frozen_path)
    for key, result in frozen["assessments"].items():
        recipe = frozen["recipes"][key]
        host.validate(result, recipe=recipe, epoch=result["evaluation_epoch"], generation_only=True)
        if recipe["memory_enabled"]:
            host.frozen_snapshots[recipe["candidate"]["candidate_id"]] = result["identity"]["snapshots"]
    ids = [row["paper_id"] for row in protocol.records("sealed_test")]
    for attempt in sorted(search["attempts"].values(), key=lambda row: row["ordinal"]):
        key = attempt["candidate_key"]
        if attempt["status"] != "complete":
            continue
        is_champion = key == frozen["winner"]["key"]
        recipe = (final["recipes"]["champion"] if is_champion else
                  {**frozen["recipes"][key], "split": "sealed_test", "paper_ids": ids})
        state["recipes"][key] = recipe
        epoch = frozen["assessments"][key]["evaluation_epoch"]
        if key not in state["results"]:
            # Reuse the identical frozen Champion's complete test receipt.
            state["results"][key] = (final["results"]["champion"] if is_champion
                                     else host.assess(recipe, epoch=epoch))
        host.validate(state["results"][key], recipe=recipe, epoch=epoch)
        atomic_write_json(path, state, immutable=False)
    state["status"] = "complete"
    atomic_write_json(path, state, immutable=False)


def run():
    with (ROOT / "pilot.lock").open("a+b") as lock:
        fcntl.flock(lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
        readiness = check()
        if readiness["status"] != "ready":
            raise RuntimeError("CoCo readiness failed; inspect readiness.json before model generation")
        os.environ["AGENTREVIEW_TELEMETRY_ROOT"] = str(ROOT / "telemetry")
        os.environ["HF_HUB_OFFLINE"] = "1"
        if not (ROOT / "launched.json").exists():
            atomic_write_json(ROOT / "launched.json", {"started": time.time(), "protocol": binding(PROTOCOL)})
        status_path = ROOT / "pilot-state.json"
        status = {"status": "running", "phase": "search", "pid": os.getpid(), "protocol": binding(PROTOCOL)}
        def save():
            status["updated_at"] = time.time()
            atomic_write_json(status_path, status, immutable=False)
        from evolution_round_report import report
        stop = threading.Event()
        def monitor():
            previous = None
            while not stop.wait(20):
                checkpoint = ROOT / "search/search.json"
                stamp = checkpoint.stat().st_mtime_ns if checkpoint.exists() else None
                if stamp != previous:
                    try:
                        report(ROOT)
                        previous = stamp
                    except Exception as exc:
                        atomic_write_json(ROOT / "report/monitor-error.json", {
                            "type": type(exc).__name__, "message": str(exc), "time": time.time()}, immutable=False)
        thread = threading.Thread(target=monitor, daemon=True)
        save()
        thread.start()
        timings = read_json(ROOT / "phase-timings.json") if (ROOT / "phase-timings.json").exists() else {}
        try:
            started = time.monotonic()
            result = run_shared_experiment(protocol_path=PROTOCOL, output_root=ROOT / "search")
            timings["search_seconds"] = timings.get("search_seconds", 0) + time.monotonic() - started
            atomic_write_json(ROOT / "phase-timings.json", timings, immutable=False)
            if result["status"] not in {"complete", "ended"} or result["winner"] is None:
                status.update(status="paused", reason="Search requires diagnosis; held-out evaluation remains sealed")
                return
            status.update(phase="final_evaluation")
            save()
            started = time.monotonic()
            final = run_shared_final_test(protocol_path=PROTOCOL, output_root=ROOT / "final",
                frozen_system_path=ROOT / "search/winner.json")
            timings["final_seconds"] = timings.get("final_seconds", 0) + time.monotonic() - started
            atomic_write_json(ROOT / "phase-timings.json", timings, immutable=False)
            if final["status"] != "complete":
                status.update(status="paused", reason="Incomplete final scoring; no missing-score imputation")
                return
            status.update(phase="held_out_round_trajectory")
            save()
            started = time.monotonic()
            evaluate_rounds(load_experiment_protocol(PROTOCOL), result, final)
            timings["round_test_seconds"] = timings.get("round_test_seconds", 0) + time.monotonic() - started
            atomic_write_json(ROOT / "phase-timings.json", timings, immutable=False)
            from paired_benchmark_report import report as paired_report
            paired_report(ROOT)
            status.update(status="complete", phase="reported", rounds_recorded=len(result["attempts"]))
        except Exception as exc:
            status.update(status="paused", error={"type": type(exc).__name__, "message": str(exc)})
            raise
        finally:
            stop.set()
            thread.join()
            save()
            report(ROOT)


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("prepare", "check", "run", "report", "allocate"))
    parser.add_argument("--gpus", type=int, nargs=4)
    parser.add_argument("--config-dir", type=Path, default=CONFIG)
    parser.add_argument("--output-root", type=Path, default=ROOT)
    arguments = parser.parse_args()
    CONFIG = arguments.config_dir.resolve()
    ROOT = arguments.output_root.resolve()
    PROTOCOL = CONFIG / "protocol.frozen.json"
    action = arguments.action
    if action == "report":
        from evolution_round_report import report
        result = report(ROOT)
        print(json.dumps({key: result[key] for key in ("status", "planned_rounds", "completed_rounds")}))
    elif action == "run":
        run()
    elif action == "allocate":
        if arguments.gpus is None:
            parser.error("allocate requires --gpus SPLIT0 SPLIT1 CLASSIFY0 CLASSIFY1")
        print(json.dumps(allocate(arguments.gpus)))
    else:
        print(json.dumps({"prepare": prepare, "check": check}[action](), ensure_ascii=False, indent=2))
