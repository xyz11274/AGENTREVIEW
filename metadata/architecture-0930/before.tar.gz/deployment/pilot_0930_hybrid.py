"""Run the same 15-paper pilot with the separately frozen 139/18 deployment."""
import argparse
import json

import pilot_0930 as pilot


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("action", choices=("check", "run", "report"))
    action = parser.parse_args().action
    pilot.CONFIG = pilot.REPO / "config/0930-pilot-hybrid"
    pilot.ROOT = pilot.REPO / "artifacts/pilot-0930-hybrid"
    pilot.PROTOCOL = pilot.CONFIG / "protocol.frozen.json"
    document = pilot.read_json(pilot.PROTOCOL)
    pilot.bound(document["implementation"]["base_launcher"])
    if action == "report":
        from evolution_round_report import report
        result = report(pilot.ROOT)
        print(json.dumps({key: result[key] for key in ("status", "planned_rounds", "completed_rounds")}))
    elif action == "check":
        print(json.dumps(pilot.check(), ensure_ascii=False, indent=2))
    else:
        pilot.run()


if __name__ == "__main__":
    main()
