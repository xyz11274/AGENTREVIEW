# AgentReview 0930：方舟 API 版本

本次任务只运行 **15 篇、5 轮自进化的小规模比较**；入口、独立数据划分和逐轮代码/评分报告见
[小规模测试说明](docs/PILOT_0930.md)。不会在结束后自动启动完整实验。下文保留原完整实验设计作为背景。

评审、记忆归纳、策略反思、Meta 汇总和 CoCo Judge 均使用方舟
`deepseek-v4.1-flash`（Plan 模型名）。返回版本必须为 `deepseek-v4-1-flash-260910`。生成默认关闭 thinking；Judge 开启 thinking，使用
`reasoning_effort=high`、`temperature=0`。只有一套方舟调用实现，无本地生成、替代模型或失败降级分支。

CoCo 论文 §5.1 的 Judge 是 GPT-5-Mini，现按用户要求替换为 DeepSeek。
作者训练的 Qwen3-8B Split/Classify、原始提示词、解析器、人工参考、评分和聚合函数保持不变；
BERTScore 的 RoBERTa 与记忆检索的 CPU Qwen3 Embedding 也保留。
因此结果属于 **CoCo 指标 + DeepSeek Judge**，不能直接当作原论文 Judge 的分数。

## 运行流程

```mermaid
flowchart LR
  D[125 篇 build 论文] --> B[方舟生成五角色无记忆经验]
  B --> M[同一 MemoryProgram 构建五份独立记忆]
  M --> R[五角色 Review → Meta 最终 Review]
  R --> S[原 CoCo Split / Classify]
  S --> J[DeepSeek Judge + 原始指标聚合]
  J --> E[static 选优 / rotating 反思]
  E --> M
  E --> F[三次搜索全部冻结]
  F --> T[1300 篇 × 8 对照组 × 3 次搜索]
```

保留 `125 / 25 / 125 / 1300` 分区、固定五角色、仅进化记忆、三次独立搜索
`0 / 1000 / 2000`、每次 20 attempts、rotating 5、父代温度 0.6。
完整论文不截断，最终测试不反馈进化。旧基准的历史使用记录仍保留。

## 配置

| 文件 | 内容 |
|---|---|
| `config/0930/protocol.seed-*.frozen.json` | 生成模型、输出预算、数据和搜索条件 |
| `config/0930/scoring.frozen.json` | 原 CoCo 源码/本地权重绑定、DeepSeek Judge 配置及替换声明 |
| `config/0930/execution.json` | 论文并行数和按完整 API 地址共享的并发上限 |
| `config/0930/services.json` | 仅 Split/Classify 的本地服务启动参数 |
| `config/0930/study.frozen.json` | 三次搜索和当前代码身份 |

云端地址为 `https://ark.cn-beijing.volces.com/api/plan/v3`，密钥仅从 `ARK_API_KEY`
读取。缺失密钥立即报错，不写入协议、请求日志或候选程序环境。
代理使用标准 `HTTPS_PROXY` / `NO_PROXY` 配置，不覆盖宿主代理。

默认云端总并发 8，由所有生成阶段和 Judge 共同使用，可按账号额度调整；
没有猜测 RPM/TPM 配额或强制固定两个论文 worker。429/临时服务错误使用有限重试，
遵守 `Retry-After`，SDK 重试关闭。
协议已经冻结：改变科学条件或代码后须重新验证并建立新身份；不能把新配置塞进旧检查点。

## 检查和启动

在本目录执行。现有验证环境是 `/data/xyj/envs/coco-original/bin/python`，无需升级该共享环境。

```bash
/data/xyj/envs/coco-original/bin/python -B deployment/workspace_0930.py check
PYTHONPATH=AgentReview /data/xyj/envs/coco-original/bin/python -B -m pytest -q -p no:cacheprovider
/data/xyj/envs/coco-original/bin/python -B deployment/api_budget_audit.py
```

`check` 只检查输入与实现绑定，不调用模型；预算审计使用仓库内固定版本的
DeepSeek tokenizer 和官方消息编码器。云服务可能添加额外消息格式，故预估与响应的实际
`usage` 分开记录，实际 usage 为计费依据。

设置密钥后先验证两种调用模式（会产生少量 API 费用）：

```bash
read -rs -p 'ARK_API_KEY: ' ARK_API_KEY
export ARK_API_KEY
/data/xyj/envs/coco-original/bin/python -B deployment/workspace_0930.py api-smoke
```

CoCo 本地专用服务使用现有权重和独立 serving 环境。查看启动参数或状态：

```bash
/data/xyj/envs/coco-original/bin/python -B deployment/coco_services.py plan --config config/0930/services.json --role split
/data/xyj/envs/coco-original/bin/python -B deployment/coco_services.py status --config config/0930/services.json --role classify
```

确认资源后将相应命令的 `plan` 改为 `start`，分别启动 split 和 classify。
只有显式执行下面的命令才启动正式实验：

```bash
/data/xyj/envs/coco-original/bin/python -B deployment/workspace_0930.py run
```

结果写入 `artifacts/study-0930-api/`。重复运行会按相同冻结身份恢复。
请求先落盘再发送；只接受一个 `finish_reason=stop` 的非空结果；保留原始响应、usage、
失败记录和重试次数。云端中断后的状态不保证服务端没有计费，但不会无限重试或偷偷换模型。

## 清理范围与证据

删除旧 role-local 进化/评估入口、本地 Qwen3.8-27B 生成与 Judge 部署、GPU 阶段轮转、
弹性借卡、历史流水线脚本及其专用测试；保留当前共享 M★ 流程、完整性/分区/角色隔离测试。
新 API 测试覆盖认证、方舟载荷、token 计数、并发、重试和损坏缓存拒绝。

`metadata/0930-migration.json`、`metadata/validation.json` 是迁移时的历史记录；
本次适配证据见 `metadata/api-adaptation-validation.json` 和 `docs/API_ADAPTATION_0930.md`。
`docs/adr/` 保留历史设计记录，旧日期部署文档不再是当前运行说明。

Plan 接口的模型名遵循[官方接入文档](https://docs.volcengine.com/docs/ark/agent-plan-enterprise-opencode?lang=zh)。已实测返回固定版本；若返回版本改变，请建立新的实验身份，不自动接受升级或换模。
